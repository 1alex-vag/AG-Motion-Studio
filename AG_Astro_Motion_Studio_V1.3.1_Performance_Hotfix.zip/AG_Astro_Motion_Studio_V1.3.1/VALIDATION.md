# V1.3.1 validation – 2026-10-08

Baseline: attached V1.2.1 hotfix. Linux x86_64, Python 3.12, NumPy 2.3.5,
OpenCV 5.0, Numba 0.68, PyQt6 6.11 offscreen, bundled imageio FFmpeg.

**27 automated tests passed on the extracted release ZIP.**

Coverage includes existing import/depth/keyframe/project/video behavior; faint
16-bit masks; observed RGB/spike identity; neutral reconstruction; neighbor halo
ownership; intensity without geometry/count changes; protection at 0/35/100%;
incoming stars; soft mask feathering; preview/final star-coordinate consistency;
compiled/Python equivalence; template reuse; depth-only sprite reuse; deterministic
opt-in synthetic stars; >32767 point sampling; serial/parallel decoded frame
ordering; unavailable/mid-export hardware fallback; safe final-quality export;
new UI defaults and full schema-4 project restoration including protection,
synthetic settings, seed, star intensity, nebula motion, encoder and workers.

Additional stress check: 36,494 actually detected separate stars from an
1800×1000 mask rendered at 640×360 without the previous sampling limit.
GUI star/export controls and neutral reconstruction were visually inspected.

## Measured comparison

Same synthetic 1600×900 source, 5,237 objects, six moving-camera poses.
Warmed median frame timings, excluding detection/JIT/scene preparation:

| Measurement | Seconds |
|---|---:|
| V1.2.1 1920×1080 frame | 0.2778 |
| V1.3.1 1920×1080 frame | 0.1870 |
| V1.3.1 Fast Preview 640×360 | 0.0180 |
| V1.3.1 12-frame 1080p CPU export, one worker | 3.037 |
| V1.3.1 same export, two workers | 2.212 |

Final frames were about 1.49× faster than the attached baseline; fast preview
about 10.4× faster than V1.3.1 final frames. Two-worker export took approximately
27% less time than one-worker export. Measurements include default V1.3.1 protection
and full star count. Source sprite extraction took 0.2542 s and is cached.
Neutral 1:1 reconstruction of this fixture had zero 8-bit mean absolute error.
Numbers are local synthetic measurements, not speed guarantees for user files/PCs.
See `benchmark.json` for raw values.

No actual GPU encoder was available: fallback was tested, real NVENC/QSV/AMF
speed and quality were not. Native Windows/macOS launch, multi-GB TIFF memory
stress and optional AI inference remain untested. Screenshots were supplied but
no full-resolution user starless/mask pair, so exact user-target comparison needs
those source files. First-use compilation can delay the first frame.
