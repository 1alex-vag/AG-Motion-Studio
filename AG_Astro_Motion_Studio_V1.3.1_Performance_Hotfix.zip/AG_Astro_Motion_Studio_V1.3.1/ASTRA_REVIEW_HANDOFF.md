# V1.3.1 review handoff

See README.md, VALIDATION.md and the included V1.3.1_Change_Spec.md.

star_catalog.py: original RGB sprites, ownership, feathering, deterministic depths
and optional separate synthetic background. sprites.py: cached atlas and compiled
bilinear compositing. protection.py: soft starless subject mask. scene3d.py:
shared camera, relative-motion protection and preview/final paths. video.py:
bounded ordered workers, verified encoder probes and CPU fallback. gui.py:
focused controls and schema-4 projects. stars.py is a compatibility import shim.

27 tests passed on extracted ZIP. Real Windows/macOS/GPU/user-TIFF validation
remains outstanding. Automatic protection is a brightness/color heuristic;
review very faint/dark nebulae, blended sources and disconnected diffraction halos.
No GPU pixel renderer or inferred hidden stars. Optional AI retained, not exercised.
