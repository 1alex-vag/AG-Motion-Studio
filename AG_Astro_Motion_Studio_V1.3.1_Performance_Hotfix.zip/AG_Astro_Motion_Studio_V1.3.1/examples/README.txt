Synthetic test fixture, not a real nebula photograph.
V1.3 original-mask sprite rendering with default nebula protection.
One-second Fly-through, 1920x1080, 12fps, CPU H.264.
