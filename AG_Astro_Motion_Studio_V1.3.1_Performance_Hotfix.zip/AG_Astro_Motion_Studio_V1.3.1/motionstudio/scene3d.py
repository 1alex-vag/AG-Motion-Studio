"""AG Astro Motion Studio: deterministic 3D star particles + depth-aware nebula camera.

3D star camera is perspective; nebula is a 2.5D depth surface (not volumetric).
Original star sprites are detected and isolated once at source resolution.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
import numpy as np
import cv2

@dataclass
class Pose:
    time: float = 0.0
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    yaw: float = 0.0
    pitch: float = 0.0
    roll: float = 0.0
    fov: float = 55.0


def default_keyframes(mode='Parallax', duration=8):
    begin = Pose(time=0)
    if mode == 'Fly-through':
        end = Pose(time=float(duration), x=.05, y=.025, z=.75, yaw=0, pitch=0, fov=55)
    elif mode == 'Orbit':
        end = Pose(time=float(duration), x=.32, y=.09, z=.12, yaw=-4, pitch=1, fov=55)
    else:
        end = Pose(time=float(duration), x=.24, y=.07, z=.08, yaw=-1.5, pitch=.5, fov=55)
    return [begin, end]


def camera_at(keyframes, seconds):
    seconds=float(seconds)
    frames = sorted(keyframes, key=lambda p: p.time)
    if not frames: return Pose()
    if seconds <= frames[0].time: return Pose(**asdict(frames[0]))
    if seconds >= frames[-1].time: return Pose(**asdict(frames[-1]))
    for a,b in zip(frames, frames[1:]):
        if a.time <= seconds <= b.time:
            f = (seconds-a.time) / max(1e-9, b.time-a.time)
            f = f*f*(3.-2.*f)
            return Pose(time=seconds, **{k:(getattr(a,k)*(1-f)+getattr(b,k)*f)
                for k in ('x','y','z','yaw','pitch','roll','fov')})
    return frames[-1]


def _rotate(dx, dy, dz, pose):
    yaw, pitch, roll = map(math.radians, (pose.yaw, pose.pitch, pose.roll))
    co, si = math.cos(yaw), math.sin(yaw)
    x, z = co*dx-si*dz, si*dx+co*dz
    co, si = math.cos(pitch), math.sin(pitch)
    y, z = co*dy-si*z, si*dy+co*z
    co, si = math.cos(roll), math.sin(roll)
    return co*x-si*y, si*x+co*y, z


def rotation(pose):
    # Columns are rotated world basis vectors. Same camera for surface and stars.
    return np.column_stack([_rotate(*v, pose) for v in np.eye(3)]).astype(np.float32)


def _sample_map_points(image, xs, ys, interpolation=cv2.INTER_LINEAR, border_mode=cv2.BORDER_REFLECT_101):
    """Vectorized point sampler with no OpenCV source/destination SHRT_MAX limit."""
    xs=np.asarray(xs,np.float32).ravel();ys=np.asarray(ys,np.float32).ravel()
    if xs.size!=ys.size:raise ValueError('Point coordinate arrays must have identical lengths')
    h,w=image.shape[:2]
    def reflect(a,size):
        if size<2:return np.zeros_like(a)
        a=np.mod(a,2*(size-1));return np.minimum(a,2*(size-1)-a)
    xs=reflect(xs,w);ys=reflect(ys,h)
    if interpolation==cv2.INTER_NEAREST:return image[np.rint(ys).astype(int),np.rint(xs).astype(int)]
    x0=np.floor(xs).astype(int);y0=np.floor(ys).astype(int)
    x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1);fx=xs-x0;fy=ys-y0
    return ((image[y0,x0]*(1-fx)+image[y0,x1]*fx)*(1-fy)+
            (image[y1,x0]*(1-fx)+image[y1,x1]*fx)*fy).astype(np.float32)


class Scene:
    def __init__(self, starless, stars, nebdepth, stardepth=None, out_w=1280, out_h=720,
                 catalog=None, detection=None, protection=None, fast_preview=False, synthetic_density=0):
        from .engine import _fit_rgb
        from .star_catalog import detect_stars, normalized_rgb, with_synthetic_background
        from .protection import nebula_protection
        if starless.shape[:2] != stars.shape[:2]:
            raise ValueError('Starless and star mask dimensions do not match')
        self.w, self.h = int(out_w), int(out_h)
        self.catalog = catalog if catalog is not None else detect_stars(stars,detection)
        if synthetic_density:self.catalog=with_synthetic_background(self.catalog,synthetic_density)
        self.fast_preview=bool(fast_preview)
        self.source_nd=nebdepth
        self.protection=protection if protection is not None else nebula_protection(starless)
        self._atlas_cache={}
        self.neb = normalized_rgb(_fit_rgb(starless,self.w,self.h))
        self.nd = _fit_rgb(nebdepth,self.w,self.h).astype(np.float32)
        self.base_depth = 3.
        self.f0 = .5*self.w/math.tan(math.radians(55)/2)
        self.cx, self.cy = (self.w-1)/2, (self.h-1)/2
        ih, iw = starless.shape[:2]
        if iw/ih > self.w/self.h:
            cw, ch = max(1,round(ih*self.w/self.h)), ih
            ox, oy = (iw-cw)//2, 0
        else:
            cw, ch = iw, max(1,round(iw*self.h/self.w))
            ox, oy = 0, (ih-ch)//2
        c = self.catalog
        self.x = (c.x-ox+.5)*self.w/cw-.5
        self.y = (c.y-oy+.5)*self.h/ch-.5
        self.radius = c.radius * .5*(self.w/cw+self.h/ch)
        self.crop=(ox,oy,cw,ch)
        self.sx,self.sy=self.w/cw,self.h/ch
        self.surface_z = 3.-.48*(_sample_map_points(nebdepth,c.x,c.y)-.5)
        self.source_protection=_sample_map_points(self.protection,c.x,c.y)
        yy,xx = np.mgrid[:self.h,:self.w].astype(np.float32)
        self.ray_x=(xx-self.cx)/self.f0;self.ray_y=(yy-self.cy)/self.f0
        self.flat_depth=float(np.mean(self.nd)) if np.ptp(self.nd)<1e-6 else None
        # Prepare static templates once, before parallel workers start.
        self.prepare_sprites(False)

    def prepare_sprites(self,bloom=False):
        from .sprites import prepare_atlas
        if bloom not in self._atlas_cache:
            self._atlas_cache[bloom]=prepare_atlas(self.catalog,self.sx,self.sy,bloom)
        return self._atlas_cache[bloom]

    def _project(self, pose, depth):
        X = (self.x-self.cx)*depth/self.f0
        Y = (self.y-self.cy)*depth/self.f0
        q = rotation(pose) @ np.array([X-pose.x,Y-pose.y,depth-pose.z])
        focal = .5*self.w/math.tan(math.radians(np.clip(pose.fov,15,120))/2)
        safe = np.maximum(q[2],.08)
        return np.column_stack((self.cx+focal*q[0]/safe,self.cy+focal*q[1]/safe)), focal/self.f0*depth/safe, q[2]>.08

    def _inverse_surface_points(self,pose,points):
        """Where projected stars land on the nebula, in source-image coordinates."""
        focal=.5*self.w/math.tan(math.radians(np.clip(pose.fov,15,120))/2)
        rays=np.c_[(points[:,0]-self.cx)/focal,(points[:,1]-self.cy)/focal,np.ones(len(points))]
        world=rays@rotation(pose)
        safe=np.where(np.abs(world[:,2])>.0001,world[:,2],.0001)
        depth=np.full(len(points),3.,np.float32)
        ox,oy,cw,ch=self.crop
        for _ in range(4):
            dist=(depth-pose.z)/safe
            sx=self.cx+self.f0*(pose.x+dist*world[:,0])/depth
            sy=self.cy+self.f0*(pose.y+dist*world[:,1])/depth
            source_x=(sx+.5)/self.sx-.5+ox;source_y=(sy+.5)/self.sy-.5+oy
            depth=3.-.48*(_sample_map_points(self.source_nd,source_x,source_y)-.5)
        return source_x,source_y

    def project_stars(self, pose, star_parallax=1., depth_spread=.6, movement=True, motion_over_nebula=.35):
        spread = np.clip(depth_spread,0,1)
        depth = 3.+(self.catalog.depth-.5)*(-3.8)*spread
        normal, scale, valid = self._project(pose,depth)
        locked, lockscale, lockvalid = self._project(pose,self.surface_z)
        par=float(np.clip(star_parallax,0,3)) if movement else 0.
        protection=self.source_protection
        amount=float(np.clip(motion_over_nebula,0,1))
        if amount<1 and par>0 and len(normal):
            # Protect both origins and possible destinations. A faint field star
            # moving into a bright core also gets a smooth reduction in motion.
            destination=locked+par*(normal-locked)
            xs,ys=self._inverse_surface_points(pose,destination)
            incoming=_sample_map_points(self.protection,xs,ys)
            ox,oy,cw,ch=self.crop
            inside=(xs>=ox)&(xs<ox+cw)&(ys>=oy)&(ys<oy+ch)
            protection=np.maximum(protection,np.where(inside,incoming,0))
        response=par*(1-protection*(1-amount))
        centers=locked+response[:,None]*(normal-locked)
        sizes=np.clip(lockscale+response*(scale-lockscale),.05,12)
        return centers,sizes,lockvalid & (valid | (response<1e-6)),depth

    def render_nebula(self, pose):
        if all(abs(getattr(pose,k))<1e-8 for k in ('x','y','z','yaw','pitch','roll')) and abs(pose.fov-55)<1e-8:
            return self.neb
        factor=math.tan(math.radians(np.clip(pose.fov,15,120))/2)/math.tan(math.radians(55)/2)
        r=rotation(pose)
        # Avoid a full HxWx3 rays/world allocation and per-pixel matrix multiply.
        rx=self.ray_x*factor;ry=self.ray_y*factor
        wx=rx*r[0,0]+ry*r[1,0]+r[2,0]
        wy=rx*r[0,1]+ry*r[1,1]+r[2,1]
        wz=rx*r[0,2]+ry*r[1,2]+r[2,2]
        safe=np.where(np.abs(wz)>.0001,wz,.0001)
        depth=3.-.48*(self.flat_depth-.5) if self.flat_depth is not None else np.full((self.h,self.w),3.,np.float32)
        iterations=1 if self.flat_depth is not None else (2 if self.fast_preview else 5)
        for _ in range(iterations):
            distance=(depth-pose.z)/safe
            sx=self.cx+self.f0*(pose.x+distance*wx)/depth
            sy=self.cy+self.f0*(pose.y+distance*wy)/depth
            if self.flat_depth is None:
                nd=cv2.remap(self.nd,sx.astype(np.float32,copy=False),sy.astype(np.float32,copy=False),cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101)
                depth=3.-.48*(nd-.5)
        neb=cv2.remap(self.neb,sx.astype(np.float32,copy=False),sy.astype(np.float32,copy=False),cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101)
        neb[(distance<=.08)|(wz<=0)]=0
        return neb

    def render(self, pose, star_parallax=1., depth_spread=.6, movement=True, brightness_boost=1., bloom=False,
               motion_over_nebula=.35, star_intensity=1.):
        from .sprites import draw_atlas
        neb=self.render_nebula(pose)
        # Changing intensity never changes the catalog, sizes or depth.
        if star_intensity<=0:return np.uint8(np.clip(neb,0,1)*255+.5)
        centers,scales,valid,_=self.project_stars(pose,star_parallax,depth_spread,movement,motion_over_nebula)
        atlas,meta=self.prepare_sprites(bloom)
        if len(meta):
            left=centers[:,0]-(meta[:,3]+.5)*scales;top=centers[:,1]-(meta[:,4]+.5)*scales
            valid &= (left<self.w)&(top<self.h)&(left+meta[:,1]*scales>0)&(top+meta[:,2]*scales>0)
        over=draw_atlas(atlas,meta,centers,scales,valid,self.w,self.h,
                        float(np.clip(star_intensity,0,2))*max(0,float(brightness_boost)))
        return np.uint8(np.clip(1-(1-neb)*(1-np.clip(over,0,1)),0,1)*255+.5)

    def debug_view(self, depth=False, spread=.6):
        img = np.zeros((self.h,self.w,3),np.uint8)
        for i,(x,y,r) in enumerate(zip(self.x,self.y,self.radius)):
            if not (0<=x<self.w and 0<=y<self.h): continue
            d = .5+(self.catalog.depth[i]-.5)*spread
            color = (round(255*d),100,round(255*(1-d))) if depth else (110,230,160)
            cv2.circle(img,(round(float(x)),round(float(y))),max(2,round(float(r))),color,1)
        return img

    def top_view(self,pose,w=900,h=520,depth_spread=.6):
        img=np.full((h,w,3),(13,20,32),np.uint8)
        _,_,_,depth=self.project_stars(Pose(),1,depth_spread)
        for z in (1.,2.,3.,4.,5.):
            py=round(h*.85-z*70)
            cv2.line(img,(20,py),(w-20,py),(45,62,81),1)
            cv2.putText(img,f'Z {z:.0f}',(24,py-8),cv2.FONT_HERSHEY_SIMPLEX,.45,(156,180,202),1)
        stride=max(1,len(depth)//2800)
        for i in range(0,len(depth),stride):
            X=(self.x[i]-self.cx)*depth[i]/self.f0
            px=round(w/2+X*100); py=round(h*.85-depth[i]*70)
            if 0<=px<w and 0<=py<h:cv2.circle(img,(px,py),1,(190,220,240),-1)
        cx=round(w/2+pose.x*100);cy=round(h*.85-pose.z*70)
        cv2.circle(img,(cx,cy),8,(50,196,255),-1)
        cv2.putText(img,'TOP VIEW - artistic star depths / camera',(22,30),cv2.FONT_HERSHEY_SIMPLEX,.6,(214,223,240),1)
        return img


def render_video_scene(scene, keyframes, path, duration, fps, star_parallax=1., depth_spread=.6,
                       progress=None, movement=True, brightness_boost=1., bloom=False,
                       motion_over_nebula=.35, star_intensity=1., workers=0, encoder='auto',status=None):
    from .video import render_video
    return render_video(scene,keyframes,path,duration,fps,star_parallax,depth_spread,progress,
                        movement,brightness_boost,bloom,motion_over_nebula,star_intensity,workers,encoder,status)
