"""Minimal PyQt6 desktop GUI for AG Astro Motion Studio V1."""
from __future__ import annotations
from pathlib import Path
import traceback
import json
import dataclasses
import numpy as np
from PIL import Image
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QPixmap, QImage
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QTabWidget, QFileDialog, QMessageBox,
    QComboBox, QSlider, QSpinBox, QDoubleSpinBox, QProgressBar, QCheckBox, QGroupBox, QScrollArea, QFormLayout, QDialog, QDialogButtonBox, QListWidget, QSplitter)
from . import engine as e
from . import scene3d as s3
from .star_catalog import detect_stars, depth_map, DetectionSettings, normalized_rgb, redistribute_depth
from .protection import nebula_protection
from .sprites import COMPILED as SPRITE_COMPILED

STYLE = '''
QWidget { background:#141820; color:#eaf0f8; font-family:Segoe UI,Arial; font-size:13px; }
QGroupBox {border:1px solid #384453; border-radius:12px; margin-top:14px; padding:13px; font-weight:600;}
QGroupBox::title {subcontrol-origin:margin;left:13px;padding:0 6px;}
QPushButton {background:#273344;border:1px solid #4a5c70;border-radius:8px;padding:8px 13px;}
QPushButton:hover{background:#32465e;} QPushButton:disabled{color:#87919f;background:#20252c;}
QPushButton#primary {background:#236bd4; border:1px solid #4589e8; font-weight:600;}
QTabWidget::pane {border:1px solid #354252;border-radius:8px;}
QTabBar::tab {padding:8px 14px;background:#232c38;} QTabBar::tab:selected{background:#3167a8;}
QComboBox,QSpinBox {background:#202935;border:1px solid #506174;padding:7px;border-radius:6px;}
QProgressBar {border-radius:5px;background:#273443;text-align:center;}
QProgressBar::chunk{background:#3887f4;border-radius:5px;}
'''


class Work(QThread):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)
    status = pyqtSignal(str)
    progress = pyqtSignal(int)

    def __init__(self, func, parent=None):
        super().__init__(parent)
        self.func = func

    def run(self):
        try:
            self.done.emit(self.func(self.status.emit, self.progress.emit))
        except Exception as ex:
            self.failed.emit(str(ex))


class ImagePreview(QLabel):
    dragged = pyqtSignal(float,float)
    wheel_zoom = pyqtSignal(int)
    def __init__(self, text='No image loaded'):
        super().__init__(text)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(350, 310)
        self.setStyleSheet('background:#0c1016;border:1px solid #34404d;border-radius:9px;color:#8496ac')
        self.rgb = None
        self._drag_origin=None

    def mousePressEvent(self,ev):
        if ev.button()==Qt.MouseButton.LeftButton and self.rgb is not None:
            self._drag_origin=ev.position()
        super().mousePressEvent(ev)

    def mouseMoveEvent(self,ev):
        if self._drag_origin is not None:
            p=ev.position()
            self.dragged.emit(float(p.x()-self._drag_origin.x()),float(p.y()-self._drag_origin.y()))
            self._drag_origin=p
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self,ev):
        self._drag_origin=None
        super().mouseReleaseEvent(ev)

    def wheelEvent(self,ev):
        if self.rgb is not None:
            self.wheel_zoom.emit(1 if ev.angleDelta().y()>0 else -1)
            ev.accept()
        else:super().wheelEvent(ev)

    def set_rgb(self, rgb):
        self.rgb = rgb
        self.refresh()

    def refresh(self):
        if self.rgb is None:
            return
        data = np.ascontiguousarray(np.uint8(normalized_rgb(self.rgb)*255+.5))
        h,w = data.shape[:2]
        q = QImage(data.data, w,h,data.strides[0], QImage.Format.Format_RGB888).copy()
        pix = QPixmap.fromImage(q)
        self.setPixmap(pix.scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, evt):
        super().resizeEvent(evt)
        self.refresh()


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('AG Astro Motion Studio V1.3.1  •  ag_astrophotography')
        self.resize(1190, 790)
        self.setStyleSheet(STYLE)
        self.starless_path = self.star_path = None
        self.starless = self.stars = self.nd = self.sd = None
        self.ai_used = False
        self.worker = None
        self.scene_cache = None
        self.catalog = None
        self.protection = None
        self.star_seed = 42
        self._last_duration = 8
        self.keyframes=s3.default_keyframes()
        self.ai_baseline=None
        central = QWidget()
        self.setCentralWidget(central)
        whole = QVBoxLayout(central)
        whole.setContentsMargins(16,14,16,13)
        heading = QLabel('AG ASTRO MOTION STUDIO')
        heading.setStyleSheet('font-size:23px;font-weight:800;color:#f3f7ff;')
        whole.addWidget(heading)
        sub = QLabel('Starless + star mask   →   Depth maps   →   AI refinement   →   Motion')
        sub.setStyleSheet('color:#93a6bd;margin-bottom:5px;')
        whole.addWidget(sub)

        body = QHBoxLayout()
        whole.addLayout(body,1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(370)
        scroll.setMaximumWidth(425)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        left = QWidget()
        left_col = QVBoxLayout(left)
        scroll.setWidget(left)
        body.addWidget(scroll)

        box1 = QGroupBox('1  IMPORT')
        l = QVBoxLayout(box1)
        self.btn_neb = QPushButton('Load Starless Image…')
        self.btn_star = QPushButton('Load Star Mask…')
        self.lbl_neb = QLabel('No starless image')
        self.lbl_star = QLabel('No star mask')
        for b, label in ((self.btn_neb,self.lbl_neb),(self.btn_star,self.lbl_star)):
            l.addWidget(b);l.addWidget(label)
            label.setWordWrap(True)
            label.setStyleSheet('color:#aebed0;font-size:11px;')
        self.btn_neb.clicked.connect(lambda:self.load_file(True))
        self.btn_star.clicked.connect(lambda:self.load_file(False))
        left_col.addWidget(box1)

        box2 = QGroupBox('2  DEPTH MAPS')
        l = QVBoxLayout(box2)
        self.btn_depth = QPushButton('Generate Depth Maps')
        self.btn_depth.setObjectName('primary')
        self.btn_depth.clicked.connect(self.make_depth)
        l.addWidget(self.btn_depth)
        self.btn_ai = QPushButton('Refine Nebula with AI (optional)')
        self.btn_ai.clicked.connect(self.refine)
        l.addWidget(self.btn_ai)
        import importlib.util
        ready=all(importlib.util.find_spec(pkg) is not None for pkg in ('transformers','torch'))
        self.ai_status=QLabel('AI dependencies: installed (weights download may be required)' if ready
                    else 'AI NOT INSTALLED  — run: pip install -r requirements-ai.txt')
        self.ai_status.setWordWrap(True)
        self.ai_status.setStyleSheet('color:#73cba6;' if ready else 'color:#e4ad63;')
        l.addWidget(self.ai_status)
        l.addWidget(QLabel('AI refinement'))
        self.ai_strength = QComboBox()
        self.ai_strength.addItems(['Gentle','Balanced','Strong'])
        self.ai_strength.setCurrentIndex(1)
        l.addWidget(self.ai_strength)
        note = QLabel('The AI model is downloaded on first use and needs internet. If unavailable, normal depth generation still works. AI depth is artistic, not actual nebula distance.')
        note.setWordWrap(True);note.setStyleSheet('color:#91a4bd;font-size:11px;')
        l.addWidget(note)
        self.btn_maps = QPushButton('Export Both Depth Maps (16-bit PNG)')
        self.btn_maps.clicked.connect(self.export_maps)
        l.addWidget(self.btn_maps)
        left_col.addWidget(box2)

        # 3D scene and manual camera share the exact video renderer.
        scene_box=QGroupBox('3  3D SCENE')
        sl=QGridLayout(scene_box)
        self.parallax=QSlider(Qt.Orientation.Horizontal)
        self.parallax.setRange(0,300);self.parallax.setValue(100)
        self.parallax_label=QLabel('100%')
        self.parallax.valueChanged.connect(lambda v:(self.parallax_label.setText(f'{v}%'),self.motion_preview()))
        self.depth_spread=QSlider(Qt.Orientation.Horizontal)
        self.depth_spread.setRange(0,100);self.depth_spread.setValue(60)
        self.depth_spread_label=QLabel('60%')
        self.depth_spread.valueChanged.connect(lambda v:(self.depth_spread_label.setText(f'{v}%'),self.motion_preview()))
        sl.addWidget(QLabel('Star Parallax'),0,0);sl.addWidget(self.parallax,0,1);sl.addWidget(self.parallax_label,0,2)
        sl.addWidget(QLabel('Star Depth Spread'),1,0);sl.addWidget(self.depth_spread,1,1);sl.addWidget(self.depth_spread_label,1,2)
        sl.addWidget(QLabel('Stars are individually projected in 3D. Nebula uses a depth surface.'),2,0,1,3)
        self.star_movement=QCheckBox('Enable star movement');self.star_movement.setChecked(True)
        self.star_movement.toggled.connect(lambda _:self.motion_preview())
        sl.addWidget(self.star_movement,3,0,1,3)
        self.star_preset=QComboBox();self.star_preset.addItems(['Custom','Natural','3D','Fly-through'])
        self.star_preset.currentTextChanged.connect(self.apply_star_preset)
        sl.addWidget(QLabel('Star preset'),4,0);sl.addWidget(self.star_preset,4,1,1,2)
        self.detection=QComboBox();self.detection.addItems(['Sensitive','Normal','Strict']);self.detection.setCurrentText('Normal')
        self.detection.currentTextChanged.connect(self.detection_changed)
        sl.addWidget(QLabel('Star Detection'),5,0);sl.addWidget(self.detection,5,1,1,2)
        self.star_count=QLabel('Stars: not detected');sl.addWidget(self.star_count,6,0,1,3)
        advanced_toggle=QPushButton('Advanced star settings ▾');advanced=QWidget();af=QFormLayout(advanced)
        self.detection_sigma=QDoubleSpinBox();self.detection_sigma.setRange(1,15);self.detection_sigma.setValue(3.5)
        self.minimum_area=QSpinBox();self.minimum_area.setRange(1,100);self.minimum_area.setValue(2)
        self.randomness=QDoubleSpinBox();self.randomness.setRange(0,1);self.randomness.setSingleStep(.05);self.randomness.setValue(.55)
        self.foreground=QDoubleSpinBox();self.foreground.setRange(-.5,.5);self.foreground.setSingleStep(.05)
        self.boost=QDoubleSpinBox();self.boost.setRange(.1,5);self.boost.setSingleStep(.1);self.boost.setValue(1)
        self.bloom=QCheckBox('Subtle bloom');self.bloom.setChecked(False)
        for title,widget in [('Detection sigma',self.detection_sigma),('Minimum area (source px)',self.minimum_area),
                             ('Depth randomness',self.randomness),('Foreground bias',self.foreground),('Brightness boost',self.boost),('Bloom',self.bloom)]:
            af.addRow(title,widget)
        for widget in (self.detection_sigma,self.minimum_area,self.randomness,self.foreground):
            widget.valueChanged.connect(self.rebuild_catalog)
        self.boost.valueChanged.connect(lambda _:self.motion_preview());self.bloom.toggled.connect(lambda _:self.motion_preview())
        advanced.hide();advanced_toggle.clicked.connect(lambda:advanced.setVisible(not advanced.isVisible()))
        sl.addWidget(advanced_toggle,7,0,1,3);sl.addWidget(advanced,8,0,1,3)
        detection_view=QPushButton('Detection view');detection_view.clicked.connect(lambda:self.debug_stars(False))
        depth_view=QPushButton('Depth view');depth_view.clicked.connect(lambda:self.debug_stars(True))
        sl.addWidget(detection_view,9,0,1,2);sl.addWidget(depth_view,9,2)
        self.original_only=QCheckBox('Use original stars only');self.original_only.setChecked(True)
        self.synthetic=QCheckBox('Add synthetic background stars');self.synthetic.setChecked(False)
        self.original_only.toggled.connect(lambda checked:self.set_synthetic(not checked))
        self.synthetic.toggled.connect(self.set_synthetic)
        self.nebula_motion=QSlider(Qt.Orientation.Horizontal);self.nebula_motion.setRange(0,100);self.nebula_motion.setValue(35)
        self.nebula_motion_label=QLabel('35%')
        self.nebula_motion.valueChanged.connect(lambda v:(self.nebula_motion_label.setText(f'{v}%'),self.motion_preview()))
        self.star_intensity=QSlider(Qt.Orientation.Horizontal);self.star_intensity.setRange(0,200);self.star_intensity.setValue(100)
        self.star_intensity_label=QLabel('100%')
        self.star_intensity.valueChanged.connect(lambda v:(self.star_intensity_label.setText(f'{v}%'),self.motion_preview()))
        # Move the existing advanced/debug rows down to keep the new main sliders visible.
        for row in (9,8,7,6,5,4,3,2):
            items=[]
            for index in range(sl.count()):
                item=sl.itemAt(index);r,c,rs,cs=sl.getItemPosition(index)
                if r==row:items.append((item.widget(),r,c,rs,cs))
            for widget,r,c,rs,cs in items:
                if widget:sl.removeWidget(widget);sl.addWidget(widget,r+4,c,rs,cs)
        sl.addWidget(QLabel('Star Motion over Nebula'),2,0);sl.addWidget(self.nebula_motion,2,1);sl.addWidget(self.nebula_motion_label,2,2)
        sl.addWidget(QLabel('Star Intensity'),3,0);sl.addWidget(self.star_intensity,3,1);sl.addWidget(self.star_intensity_label,3,2)
        sl.addWidget(self.original_only,4,0,1,3);sl.addWidget(self.synthetic,5,0,1,3)
        self.synthetic_density=QSpinBox();self.synthetic_density.setRange(0,5000);self.synthetic_density.setValue(300)
        self.synthetic_density.setSuffix(' / MP');self.synthetic_density.setEnabled(False)
        self.synthetic_density.valueChanged.connect(lambda _:self.motion_preview())
        af.addRow('Synthetic density',self.synthetic_density)
        protect_view=QPushButton('Nebula protection view');protect_view.clicked.connect(self.protection_preview)
        sl.addWidget(protect_view,14,0,1,3)
        left_col.addWidget(scene_box)

        camera_box=QGroupBox('4  CAMERA / KEYFRAMES')
        cg=QGridLayout(camera_box)
        self.cam={}
        values={'x':(-3,3,0),'y':(-3,3,0),'z':(-1.5,2.,0),
                'yaw':(-45,45,0),'pitch':(-45,45,0),'roll':(-45,45,0),'fov':(15,120,55)}
        for idx,(name,(lo,hi,default)) in enumerate(values.items()):
            inp=QDoubleSpinBox();inp.setRange(lo,hi);inp.setDecimals(2)
            inp.setSingleStep(.05 if name in ('x','y','z') else 1)
            inp.setValue(default);self.cam[name]=inp
            inp.valueChanged.connect(self._camera_changed)
            cg.addWidget(QLabel(name.upper()),idx//2,2*(idx%2))
            cg.addWidget(inp,idx//2,2*(idx%2)+1)
        self.kf_list=QListWidget();self.kf_list.setMaximumHeight(94)
        self.kf_list.currentRowChanged.connect(self.select_keyframe)
        cg.addWidget(self.kf_list,4,0,1,4)
        addbtn=QPushButton('Add / Replace at time')
        delbtn=QPushButton('Delete keyframe')
        addbtn.clicked.connect(self.add_keyframe)
        delbtn.clicked.connect(self.delete_keyframe)
        cg.addWidget(addbtn,5,0,1,2);cg.addWidget(delbtn,5,2,1,2)
        self.btn_top=QPushButton('Top View')
        self.btn_top.clicked.connect(self.top_preview)
        cg.addWidget(self.btn_top,6,0,1,4)
        cg.addWidget(QLabel('Drag preview = yaw/pitch · Mouse wheel = Z · Add keyframe to keep changes.'),7,0,1,4)
        left_col.addWidget(camera_box)

        box3 = QGroupBox('5  VIDEO EXPORT')
        g = QGridLayout(box3)
        self.mode = QComboBox();self.mode.addItems(['Parallax','Fly-through','Orbit','Manual'])
        self.mode.currentTextChanged.connect(self._mode_changed)
        self.duration = QSpinBox();self.duration.setRange(2,30);self.duration.setValue(8);self.duration.setSuffix(' sec')
        self.fps = QComboBox();self.fps.addItems(['24','30','60']);self.fps.setCurrentIndex(1)
        self.preset = QComboBox();self.preset.addItems(['1920×1080','1080×1920','1280×720','720×1280','3840×2160'])
        self.preset.setCurrentIndex(2)
        self.intensity = QSlider(Qt.Orientation.Horizontal);self.intensity.setRange(0,100);self.intensity.setValue(50)
        for row,(lab,widget) in enumerate([('Mode',self.mode),('Duration',self.duration),('FPS',self.fps),('Format',self.preset),('Motion strength',self.intensity)]):
            g.addWidget(QLabel(lab),row,0);g.addWidget(widget,row,1)
        self.btn_preview = QPushButton('Preview Current Frame')
        self.btn_preview.clicked.connect(self.motion_preview)
        self.btn_render = QPushButton('Render MP4…')
        self.btn_render.setObjectName('primary')
        self.btn_render.clicked.connect(self.export_video)
        self.preview_quality=QComboBox();self.preview_quality.addItems(['Fast Preview','Final-quality Preview'])
        self.preview_quality.currentTextChanged.connect(lambda _:self.motion_preview())
        self.encoder=QComboBox();self.encoder.addItems(['Auto (GPU if available)','CPU – H.264','NVIDIA NVENC','Intel Quick Sync','AMD AMF'])
        self.frame_workers=QSpinBox();self.frame_workers.setRange(0,8);self.frame_workers.setValue(0)
        self.frame_workers.setSpecialValueText('Auto');self.frame_workers.setToolTip('Parallel frames. Auto is bounded by CPU and frame memory.')
        g.addWidget(QLabel('Preview quality'),5,0);g.addWidget(self.preview_quality,5,1)
        g.addWidget(QLabel('Video encoder'),6,0);g.addWidget(self.encoder,6,1)
        g.addWidget(QLabel('Frame workers'),7,0);g.addWidget(self.frame_workers,7,1)
        g.addWidget(self.btn_preview,8,0,1,2);g.addWidget(self.btn_render,9,0,1,2)
        left_col.addWidget(box3)
        projects=QGroupBox('6  PROJECT');pl=QHBoxLayout(projects)
        save=QPushButton('Save project…');load=QPushButton('Open project…')
        save.clicked.connect(self.save_scene_project);load.clicked.connect(self.load_scene_project)
        pl.addWidget(save);pl.addWidget(load);left_col.addWidget(projects)
        self.project_buttons=(save,load)
        for label in left.findChildren(QLabel):label.setWordWrap(True)
        left_col.addStretch(1)

        right = QVBoxLayout()
        body.addLayout(right,1)
        self.tabs = QTabWidget()
        self.views = {}
        for name in ['Starless','Star mask','Nebula depth','Star depth','Star Detection','Nebula protection','3D Preview']:
            view = ImagePreview('Load images to begin' if name in ('Starless','Star mask') else 'Generate depth maps to begin')
            self.views[name]=view
            self.tabs.addTab(view,name)
        self.views['3D Preview'].dragged.connect(self.drag_camera)
        self.views['3D Preview'].wheel_zoom.connect(self.zoom_camera)
        right.addWidget(self.tabs,1)
        frame_control = QHBoxLayout()
        frame_control.addWidget(QLabel('Preview position'))
        self.timeline = QSlider(Qt.Orientation.Horizontal);self.timeline.setRange(0,100);self.timeline.setValue(40)
        self.timeline.valueChanged.connect(self.motion_preview)
        frame_control.addWidget(self.timeline)
        right.addLayout(frame_control)
        self.status = QLabel('Ready. Import a starless image and matching star mask.')
        self._updating_cam=False
        self._refresh_keyframes()
        self.status.setWordWrap(True)
        self.progress = QProgressBar();self.progress.setValue(0)
        whole.addWidget(self.status);whole.addWidget(self.progress)
        self.duration.valueChanged.connect(self.duration_changed)
        self.preset.currentTextChanged.connect(self.motion_preview)
        self.intensity.valueChanged.connect(self.motion_preview)
        self._update_buttons()

    def _update_buttons(self):
        ready = self.starless is not None and self.stars is not None
        maps = ready and self.nd is not None and self.sd is not None
        busy = self.worker is not None and self.worker.isRunning()
        self.btn_depth.setEnabled(ready and not busy)
        self.btn_ai.setEnabled(maps and not busy)
        self.btn_maps.setEnabled(maps and not busy)
        self.btn_preview.setEnabled(maps and not busy)
        self.btn_render.setEnabled(maps and not busy)
        self.btn_top.setEnabled(maps and not busy)
        self.btn_neb.setEnabled(not busy)
        self.btn_star.setEnabled(not busy)
        for b in self.project_buttons:b.setEnabled(not busy)

    def load_file(self, neb):
        path,_=QFileDialog.getOpenFileName(self,'Choose '+('starless image' if neb else 'star mask'),'',
                                              'Astrophotography (*.fits *.fit *.fts *.tif *.tiff *.png *.jpg *.jpeg)')
        if not path:return
        try:
            img=e.load_image(path)
            if neb:
                self.starless=img;self.starless_path=path
                self.lbl_neb.setText(Path(path).name+'  •  '+str(img.shape[1])+'×'+str(img.shape[0]))
                self.views['Starless'].set_rgb(img)
            else:
                self.stars=img;self.star_path=path
                self.lbl_star.setText(Path(path).name+'  •  '+str(img.shape[1])+'×'+str(img.shape[0]))
                self.views['Star mask'].set_rgb(img)
            self.nd=self.sd=None
            self.scene_cache=None
            self.catalog=None
            self.protection=None
            self.star_count.setText("Stars: not detected")
            self.ai_used=False
            if self.starless is not None and self.stars is not None:
                e.validate_pair(self.starless,self.stars)
                self.status.setText('Both images loaded and dimensions match. Generate Depth Maps.')
            else:
                self.status.setText('Loaded. Import the matching second image.')
            self._update_buttons()
        except Exception as exc:
            self.status.setText(str(exc))
            QMessageBox.warning(self,'Import issue',str(exc))
            self._update_buttons()

    def make_depth(self):
        try:
            e.validate_pair(self.starless,self.stars)
            self.status.setText('Generating two artistic depth maps…')
            QApplication.processEvents()
            self.nd=e.nebula_depth(self.starless)
            self.catalog=detect_stars(self.stars,self.detection_settings())
            self.protection=nebula_protection(self.starless)
            self.views["Nebula protection"].set_rgb(e.preview_depth(self.protection))
            self.sd=depth_map(self.catalog)
            self.star_count.setText(f"Stars: {len(self.catalog):,}")
            self.ai_used=False
            self.scene_cache=None
            self.views['Nebula depth'].set_rgb(e.preview_depth(self.nd))
            self.views['Star depth'].set_rgb(e.preview_depth(self.sd))
            self.tabs.setCurrentWidget(self.views['Nebula depth'])
            self.status.setText('Depth maps ready. Optional: AI refinement, then preview or render.')
            self.progress.setValue(100)
            self._update_buttons()
        except Exception as ex:
            QMessageBox.critical(self,'Depth generation error',str(ex))

    def _start_work(self, task, after):
        if self.worker and self.worker.isRunning():return
        self.progress.setValue(0)
        self.worker=Work(task,self)
        self.worker.status.connect(self.status.setText)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.done.connect(after)
        self.worker.failed.connect(self._on_failure)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()
        self._update_buttons()

    def _on_failure(self, msg):
        self.status.setText(msg)
        QMessageBox.critical(self,'Operation failed',msg)

    def _on_finished(self):
        self.worker=None
        self._update_buttons()

    def refine(self):
        strength=[.3,.6,.85][self.ai_strength.currentIndex()]
        image=self.starless.copy();baseline=self.nd.copy()
        import importlib.util
        if any(importlib.util.find_spec(pkg) is None for pkg in ('transformers','torch')):
            QMessageBox.warning(self,'AI not installed',
                'Install the real AI dependencies in this application environment:\n'
                'pip install -r requirements-ai.txt\n\nModel weights are downloaded on first use.')
            return
        if QMessageBox.question(self,'AI model download',
             'AI refinement uses Depth Anything V2 Small. First use may download model weights. Continue?',
             QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
             QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:return
        def task(status,progress):
            return e.refine_nebula_ai(image,baseline,strength,status=status)
        def done(depth):
            self.nd=depth;self.ai_used=True;self.scene_cache=None
            self.views['Nebula depth'].set_rgb(e.preview_depth(depth))
            self.tabs.setCurrentWidget(self.views['Nebula depth'])
            self.status.setText('Real AI model refinement completed. Star depth remains separate.')
            self.progress.setValue(100)
        self._start_work(task,done)

    def _settings(self):
        import re
        w,h=map(int,re.findall(r'\d+',self.preset.currentText()))
        return e.MotionSettings(mode=self.mode.currentText(),duration=self.duration.value(),
            fps=int(self.fps.currentText()),intensity=self.intensity.value()/100,
            width=w,height=h)

    def _mode_changed(self, mode):
        if mode == 'Manual': return
        if hasattr(self,'kf_list') and self.keyframes:
            if QMessageBox.question(self,'Replace camera path?',
                  'Replace existing camera keyframes with the '+mode+' preset?',
                  QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                  QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                self.mode.blockSignals(True);self.mode.setCurrentText('Manual');self.mode.blockSignals(False)
                return
        self.keyframes=s3.default_keyframes(mode,self.duration.value())
        self._refresh_keyframes()
        self.motion_preview()

    def drag_camera(self,dx,dy):
        self._updating_cam=True
        self.cam['yaw'].setValue(self.cam['yaw'].value()+dx*.12)
        self.cam['pitch'].setValue(self.cam['pitch'].value()+dy*.12)
        self._updating_cam=False
        self.motion_preview(manual=True)

    def zoom_camera(self,step):
        self.cam['z'].setValue(self.cam['z'].value()+step*.08)

    def _current_pose(self):
        return s3.Pose(time=self.duration.value()*self.timeline.value()/100,
                       **{k:v.value() for k,v in self.cam.items()})

    def _camera_changed(self, *_):
        if getattr(self,'_updating_cam',True):return
        self.motion_preview(manual=True)

    def _set_camera(self, pose):
        self._updating_cam=True
        for name,box in self.cam.items():box.setValue(getattr(pose,name))
        self._updating_cam=False

    def _refresh_keyframes(self):
        self.kf_list.blockSignals(True)
        self.kf_list.clear()
        for f in sorted(self.keyframes,key=lambda p:p.time):
            self.kf_list.addItem(f'◆  {f.time:.2f}s     X {f.x:.2f}  Y {f.y:.2f}  Z {f.z:.2f}')
        self.kf_list.blockSignals(False)

    def select_keyframe(self,idx):
        if idx < 0 or idx>=len(self.keyframes):return
        p=sorted(self.keyframes,key=lambda f:f.time)[idx]
        self.timeline.blockSignals(True)
        self.timeline.setValue(int(round(100*p.time/self.duration.value())))
        self.timeline.blockSignals(False)
        self._set_camera(p)
        self.motion_preview(manual=True)

    def add_keyframe(self):
        self.mode.blockSignals(True);self.mode.setCurrentText('Manual');self.mode.blockSignals(False)
        current=self._current_pose()
        self.keyframes=[k for k in self.keyframes if abs(k.time-current.time)>.05]+[current]
        self.keyframes.sort(key=lambda k:k.time)
        self._refresh_keyframes()
        self.status.setText('Camera keyframe saved at %.2fs.'%current.time)

    def delete_keyframe(self):
        idx=self.kf_list.currentRow()
        if idx>=0 and len(self.keyframes)>1:
            self.keyframes.pop(idx)
            self._refresh_keyframes()
            self.motion_preview()

    def _get_scene(self,w,h,fast_preview=False):
        if self.protection is None:self.protection=nebula_protection(self.starless)
        density=self.synthetic_density.value() if self.synthetic.isChecked() else 0
        key=(w,h,fast_preview,density,id(self.nd),id(self.sd),id(self.starless),id(self.stars),id(self.catalog),id(self.protection))
        if self.scene_cache is None or self.scene_cache[0]!=key:
            self.scene_cache=(key,s3.Scene(self.starless,self.stars,self.nd,self.sd,w,h,catalog=self.catalog,
                    protection=self.protection,fast_preview=fast_preview,synthetic_density=density))
        return self.scene_cache[1]

    def set_synthetic(self, enabled):
        for widget in (self.original_only,self.synthetic):widget.blockSignals(True)
        self.synthetic.setChecked(enabled);self.original_only.setChecked(not enabled)
        for widget in (self.original_only,self.synthetic):widget.blockSignals(False)
        self.synthetic_density.setEnabled(enabled)
        self.scene_cache=None;self.motion_preview()

    def protection_preview(self):
        if self.protection is None:return
        self.views['Nebula protection'].set_rgb(e.preview_depth(self.protection))
        self.tabs.setCurrentWidget(self.views['Nebula protection'])
        self.status.setText('Soft nebula protection: warm colors protect the subject; dark blue allows normal star motion.')


    def top_preview(self):
        if self.nd is None:return
        pose=self._current_pose()
        scene=self._get_scene(900,520)
        self.views['3D Preview'].set_rgb(scene.top_view(pose,depth_spread=self.depth_spread.value()/100))
        self.tabs.setCurrentWidget(self.views['3D Preview'])
        self.status.setText('Top view: 3D stars and camera position (cyan).')

    def motion_preview(self, value=None, manual=False):
        if not hasattr(self,'nd') or self.nd is None:return
        settings=self._settings()
        fast=self.preview_quality.currentIndex()==0
        limit=640 if fast else 900
        scale=min(1.,limit/max(settings.width,settings.height))
        w=max(2,int(settings.width*scale)//2*2)
        h=max(2,int(settings.height*scale)//2*2)
        try:
            scene=self._get_scene(w,h,fast_preview=fast)
            t=self.duration.value()*self.timeline.value()/100
            pose=self._current_pose() if manual else s3.camera_at(self.render_keyframes(),t)
            if not manual:self._set_camera(pose)
            frame=scene.render(pose,self.parallax.value()/100,self.depth_spread.value()/100,
                               self.star_movement.isChecked(),self.boost.value(),self.bloom.isChecked(),
                               self.nebula_motion.value()/100,self.star_intensity.value()/100)
            self.views['3D Preview'].set_rgb(frame)
            self.tabs.setCurrentWidget(self.views['3D Preview'])
        except Exception as exc:
            self.status.setText('Preview error: '+str(exc))

    def duration_changed(self, value):
        factor=value/max(1,self._last_duration)
        self.keyframes=[dataclasses.replace(k,time=k.time*factor) for k in self.keyframes]
        self._last_duration=value
        self._refresh_keyframes();self.motion_preview()

    def detection_settings(self):
        return DetectionSettings(sigma=self.detection_sigma.value(),min_area=self.minimum_area.value(),
             randomness=self.randomness.value(),foreground_bias=self.foreground.value(),seed=self.star_seed)

    def detection_changed(self, name):
        self.detection_sigma.setValue({'Sensitive':2.5,'Normal':3.5,'Strict':5.}[name])

    def rebuild_catalog(self, *_):
        if self.stars is None or self.nd is None:return
        try:
            settings=self.detection_settings()
            previous=self.catalog.settings if self.catalog is not None else None
            if previous and (previous.sigma,previous.min_area)==(settings.sigma,settings.min_area):
                self.catalog=redistribute_depth(self.catalog,settings)
            else:self.catalog=detect_stars(self.stars,settings)
            self.sd=depth_map(self.catalog);self.scene_cache=None
            self.star_count.setText(f'Stars: {len(self.catalog):,}')
            self.views['Star depth'].set_rgb(e.preview_depth(self.sd))
            self.motion_preview()
        except Exception as ex:self.status.setText('Star detection error: '+str(ex))

    def apply_star_preset(self, name):
        if name not in ('Natural','3D','Fly-through'):return
        par,spread={'Natural':(80,45),'3D':(120,70),'Fly-through':(180,90)}[name]
        self.parallax.setValue(par);self.depth_spread.setValue(spread)

    def debug_stars(self, depth=False):
        if self.catalog is None:return
        settings=self._settings();scale=min(1.,900/max(settings.width,settings.height))
        scene=self._get_scene(max(2,int(settings.width*scale)//2*2),max(2,int(settings.height*scale)//2*2))
        view=self.views['Star Detection']
        view.set_rgb(scene.debug_view(depth,self.depth_spread.value()/100))
        self.tabs.setCurrentWidget(view)
        self.status.setText(f'{len(self.catalog):,} source stars. Depth colors: red near / blue far.' if depth
                            else f'{len(self.catalog):,} source stars. Green circles mark detected centers.')

    def render_keyframes(self):
        frames=[dataclasses.replace(k) for k in self.keyframes]
        strength=self.intensity.value()/50
        # Motion strength applies to the path, not manually entered keyframes.
        if self.mode.currentText()!='Manual' and frames:
            origin=frames[0]
            for frame in frames[1:]:
                for k in ('x','y','z','yaw','pitch','roll'):
                    setattr(frame,k,getattr(origin,k)+(getattr(frame,k)-getattr(origin,k))*strength)
        return frames

    def project_document(self):
        return {'schema':4,'application':'AG Astro Motion Studio V1.3.1',
          'starless':self.starless_path,'star_mask':self.star_path,'ai_used':self.ai_used,
          'animation':dataclasses.asdict(self._settings()),
          'star_parallax':self.parallax.value()/100,'star_depth_spread':self.depth_spread.value()/100,
          'star_movement':self.star_movement.isChecked(),'brightness_boost':self.boost.value(),
          'star_motion_over_nebula':self.nebula_motion.value()/100,'star_intensity':self.star_intensity.value()/100,
          'original_stars_only':self.original_only.isChecked(),'synthetic_background':self.synthetic.isChecked(),
          'synthetic_density':self.synthetic_density.value(),'preview_quality':self.preview_quality.currentIndex(),
          'video_encoder':self.encoder.currentIndex(),'frame_workers':self.frame_workers.value(),
          'bloom':self.bloom.isChecked(),'detection':dataclasses.asdict(self.detection_settings()),
          'keyframes':[dataclasses.asdict(k) for k in self.keyframes],
          'note':'Artistic relative depths; isolated observed star sprites, synthetic background opt-in only.'}

    def write_project(self,path):
        path=Path(path)
        doc=self.project_document()
        if self.nd is not None:
            depth_path=path.with_suffix('.depth.npz')
            np.savez_compressed(depth_path,nebula=self.nd,protection=self.protection)
            doc['nebula_depth_file']=depth_path.name
        path.write_text(json.dumps(doc,indent=2),encoding='utf-8')

    def save_scene_project(self):
        if self.nd is None:return
        path,_=QFileDialog.getSaveFileName(self,'Save project','motion_project.json','JSON (*.json)')
        if not path:return
        try:self.write_project(path);self.status.setText('Project saved with camera, stars and nebula depth.')
        except Exception as ex:QMessageBox.critical(self,'Save failed',str(ex))

    def load_scene_project(self):
        if self.worker and self.worker.isRunning():return
        path,_=QFileDialog.getOpenFileName(self,'Open project','','JSON (*.json)')
        if not path:return
        try:
            doc=json.loads(Path(path).read_text(encoding='utf-8'))
            def resolve(value):
                p=Path(value);return p if p.is_absolute() else Path(path).parent/p
            nebpath=resolve(doc['starless']);starpath=resolve(doc['star_mask'])
            neb=e.load_image(nebpath);stars=e.load_image(starpath);e.validate_pair(neb,stars)
            nd=e.nebula_depth(neb)
            protection=nebula_protection(neb)
            if doc.get('nebula_depth_file'):
                with np.load(resolve(doc['nebula_depth_file']),allow_pickle=False) as saved:
                    nd=saved['nebula'].copy()
                    if 'protection' in saved:protection=saved['protection'].copy()
                if nd.shape!=neb.shape[:2] or protection.shape!=neb.shape[:2]:raise ValueError('Saved depth/protection dimensions differ')
            detection=DetectionSettings(**doc.get('detection',{}))
            catalog=detect_stars(stars,detection)
            frames=[s3.Pose(**k) for k in doc.get('keyframes',[])] or s3.default_keyframes()
            self.starless_path=str(nebpath);self.star_path=str(starpath)
            self.starless=neb;self.stars=stars;self.nd=nd;self.catalog=catalog;self.sd=depth_map(catalog)
            self.protection=protection
            self.scene_cache=None;self.ai_used=bool(doc.get('ai_used',False))
            anim=doc.get('animation',{})
            controls=[self.mode,self.duration,self.fps,self.preset,self.intensity,self.parallax,self.depth_spread,
                      self.star_movement,self.boost,self.bloom,self.detection_sigma,self.minimum_area,self.randomness,self.foreground,
                      self.nebula_motion,self.star_intensity,self.original_only,self.synthetic,self.synthetic_density,
                      self.preview_quality,self.encoder,self.frame_workers]
            for widget in controls:widget.blockSignals(True)
            try:
                self.mode.setCurrentText(anim.get('mode','Manual'));self.duration.setValue(anim.get('duration',8))
                self.fps.setCurrentText(str(anim.get('fps',30)))
                self.preset.setCurrentText(f"{anim.get('width',1280)}×{anim.get('height',720)}")
                self.intensity.setValue(round(anim.get('intensity',.5)*100))
                self.parallax.setValue(round(doc.get('star_parallax',1)*100));self.depth_spread.setValue(round(doc.get('star_depth_spread',.6)*100))
                self.star_movement.setChecked(doc.get('star_movement',True));self.boost.setValue(doc.get('brightness_boost',1))
                self.bloom.setChecked(doc.get('bloom',False));self.detection_sigma.setValue(detection.sigma)
                self.minimum_area.setValue(detection.min_area);self.randomness.setValue(detection.randomness)
                self.foreground.setValue(detection.foreground_bias)
                self.nebula_motion.setValue(round(doc.get('star_motion_over_nebula',.35)*100))
                self.star_intensity.setValue(round(doc.get('star_intensity',1)*100))
                synthetic=bool(doc.get('synthetic_background',False))
                self.synthetic.setChecked(synthetic);self.original_only.setChecked(not synthetic)
                self.synthetic_density.setValue(doc.get('synthetic_density',300));self.synthetic_density.setEnabled(synthetic)
                self.preview_quality.setCurrentIndex(doc.get('preview_quality',0));self.encoder.setCurrentIndex(doc.get('video_encoder',0))
                self.frame_workers.setValue(doc.get('frame_workers',0))
            finally:
                for widget in controls:widget.blockSignals(False)
            self.star_seed=detection.seed
            self._last_duration=self.duration.value()
            self.keyframes=frames;self._refresh_keyframes()
            self.parallax_label.setText(f'{self.parallax.value()}%');self.depth_spread_label.setText(f'{self.depth_spread.value()}%')
            self.nebula_motion_label.setText(f'{self.nebula_motion.value()}%');self.star_intensity_label.setText(f'{self.star_intensity.value()}%')
            self.views['Nebula protection'].set_rgb(e.preview_depth(self.protection))
            self.lbl_neb.setText(nebpath.name);self.lbl_star.setText(starpath.name)
            self.star_count.setText(f'Stars: {len(catalog):,}')
            for name,image in [('Starless',neb),('Star mask',stars),('Nebula depth',e.preview_depth(nd)),('Star depth',e.preview_depth(self.sd))]:
                self.views[name].set_rgb(image)
            self._update_buttons();self.motion_preview();self.status.setText('Project restored.')
        except Exception as ex:QMessageBox.critical(self,'Open failed',str(ex))


    def export_maps(self):
        target=QFileDialog.getExistingDirectory(self,'Export depth maps')
        if not target:return
        try:
            e.save_depth(self.nd,Path(target)/'nebula_depth_16bit.png')
            e.save_depth(self.sd,Path(target)/'stars_depth_16bit.png')
            e.save_depth(self.protection,Path(target)/'nebula_protection_16bit.png')
            self.write_project(Path(target)/'motion_project.json')
            self.status.setText('Saved nebula depth, star depth, nebula protection and project.')
        except Exception as exc:QMessageBox.critical(self,'Export error',str(exc))

    def export_video(self):
        if not SPRITE_COMPILED:
            QMessageBox.warning(self, 'Slow renderer active',
                'Numba acceleration is not active. Final rendering will be extremely slow and limited to one frame worker.\n\n'
                'Run INSTALL_WINDOWS.bat again, or install with:\npython -m pip install numba\n\nThen restart AG Astro Motion Studio.')
        path,_=QFileDialog.getSaveFileName(self,'Export animation','AG_Astro_Motion.mp4','MP4 Video (*.mp4)')
        if not path:return
        settings=self._settings()
        # Inputs are read-only during export; imports/AI/project loading are disabled.
        # Keep references rather than duplicating multi-GB source arrays.
        n,st,nd,sd=self.starless,self.stars,self.nd,self.sd
        frames=self.render_keyframes()
        catalog=self.catalog
        protection=self.protection
        density=self.synthetic_density.value() if self.synthetic.isChecked() else 0
        over_nebula=self.nebula_motion.value()/100;star_intensity=self.star_intensity.value()/100
        workers=self.frame_workers.value();encoder=['auto','cpu','nvenc','qsv','amf'][self.encoder.currentIndex()]
        movement=self.star_movement.isChecked();boost=self.boost.value();bloom=self.bloom.isChecked()
        doc=self.project_document()
        par=self.parallax.value()/100
        spread=self.depth_spread.value()/100
        duration=settings.duration;fps=settings.fps
        def task(status,progress):
            status('Building 3D star scene and rendering MP4…')
            scene=s3.Scene(n,st,nd,sd,settings.width,settings.height,catalog=catalog,protection=protection,synthetic_density=density)
            encoding=s3.render_video_scene(scene,frames,path,duration,fps,par,spread,
                 progress=lambda done,total:progress(int(100*done/total)),
                 movement=movement,brightness_boost=boost,bloom=bloom,motion_over_nebula=over_nebula,
                 star_intensity=star_intensity,workers=workers,encoder=encoder,status=status)
            project_path=Path(path).with_suffix('.json')
            depth_path=project_path.with_suffix('.depth.npz')
            np.savez_compressed(depth_path,nebula=nd,protection=protection)
            doc['nebula_depth_file']=depth_path.name
            doc['render_result']=encoding
            project_path.write_text(json.dumps(doc,indent=2),encoding='utf-8')
            return path
        def done(out):
            self.status.setText('Video rendered: '+str(out))
            self.progress.setValue(100)
            QMessageBox.information(self,'Render complete','Saved:\n'+str(out))
        self._start_work(task,done)


def main():
    import sys
    app=QApplication(sys.argv)
    gui=Main()
    gui.show()
    sys.exit(app.exec())

if __name__=='__main__':main()
