# V1.3.1 performance hotfix

- Fixes missing `numba` dependency in V1.3 `requirements.txt`.
- Without Numba the star compositor falls back to pure Python and forces one frame worker, which can make dense-star renders tens of minutes long.
- Installer now verifies Numba acceleration.
- Export warns if the slow fallback renderer is active.

# AG Astro Motion Studio V1.3.1

Desktop animation tool for a matching **starless image + observed star mask**.
V1.3.1 preserves the existing import, depth, optional AI, camera/keyframe and project
workflow while changing the star renderer and export pipeline.

## Install and start

This ZIP contains Python source and launch scripts, not a standalone EXE.
Use Python 3.10 or newer supported by the dependencies (tested here with 3.12).

Windows: extract the entire ZIP, run `INSTALL_WINDOWS.bat`, then `START_WINDOWS.bat`.
Re-run installation when upgrading: V1.3.1 adds Numba for CPU sprite acceleration.

macOS: run `INSTALL_MAC.command`, then `START_MAC.command`. If needed, make the
scripts executable with `chmod +x *.command`.

Linux: `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`,
then `.venv/bin/python -m motionstudio.gui`.

The first rendered frame may take extra time to compile the sprite compositor.
Subsequent frames use its cached compiled code. Without Numba the compatible
Python compositor works, but is substantially slower and export uses one worker.

## Workflow

1. Load a stretched starless image and matching star mask with identical size,
crop and pixel alignment. PNG/JPG, TIFF and FITS are supported.
2. Click **Generate Depth Maps**. This also extracts the observed star sprites
and builds the soft nebula protection mask, once.
3. Keep **Use original stars only** enabled. Try the **3D** star preset.
4. Scrub the timeline or edit the existing camera controls. Save manual camera
changes with **Add / Replace at time** before export.
5. Use **Fast Preview** for iteration. **Final-quality Preview** uses the final
surface solver at a display-sized resolution. MP4 export always uses the selected
full output resolution and complete catalog.
6. **Render MP4…** saves the video plus a project JSON and `.depth.npz` sidecar.

The preview remains a single frame with timeline scrubbing, as in V1.2.1.
The main groups, image tabs, depth export, optional AI refinement and camera
controls are retained. New controls are limited to stars and rendering.

## Star controls

| Control | Default | Behavior |
|---|---:|---|
| Enable star movement | On | Off makes stars follow the local nebula surface |
| Use original stars only | On | Observed stars retain their extracted appearance |
| Add synthetic background stars | Off | Separate, faint, deterministic artistic additions |
| Star Parallax | 100% | 0% follows nebula; 100% natural projection; up to 300% relative motion |
| Star Depth Spread | 60% | 0% one star plane; 100% strong artistic depth spread |
| Star Motion over Nebula | 35% | 0% nearly locks strongly protected stars; 100% full relative motion |
| Star Intensity | 100% | 0–200%, scales light without changing star count or geometry |

The protection mask is derived from broad brightness/color structure in the
starless image and feathered. Both a star's original location and its projected
arrival over the moving nebula are considered. Partial mask values give smooth
transitions. **Nebula protection view** shows it: warm colors are protected,
dark blue permits normal motion. At 0%, only fully protected regions are exactly
locked; feathered regions retain proportionate motion.

Original stars are not regenerated as Gaussian dots. Each connected component
uses its isolated original RGB pixels, including connected spikes and local
halos. Neighboring sprite halos are assigned to one source, preventing duplicates.
Black sprite pixels contribute no light, and outer support is softly feathered.
At a neutral 1:1 camera with default intensity and Bloom off, accepted stars
closely reconstruct the input mask. There is no global moving star-mask texture.

Advanced settings remain collapsed: detection sigma, minimum source-pixel area,
brightness boost, depth randomness, foreground bias, Bloom and synthetic density.
Bloom is now **off by default** to retain original profiles; enabling it adds a
small glow derived from each actual sprite. Intensity multiplies brightness boost.
Synthetic density (stars per source megapixel) is enabled only when additions are
explicitly turned on. It adds stars and never replaces the real catalog.

Detection/depth debug views, top view, camera presets and motion-strength behavior
remain available. Motion strength scales preset paths; manual keyframes are kept.

## Performance and encoding

- Fast Preview: longest side up to 640 pixels, two depth-surface iterations.
- Final-quality Preview: up to 900 pixels, five surface iterations.
- Final export: chosen resolution, all observed stars, full surface processing.
- Original detection, RGB sprites, artificial depths, nebula depth and protection
are cached. Camera/parallax/intensity edits do not run source detection again.
- Depth randomness/bias edits reuse sprite extraction. Preview/output-size changes
prepare an appropriately scaled atlas from the same original catalog.
- Vectorized projection plus a compiled, GIL-free sprite compositor replaces
per-frame Gaussian creation. Atlas templates are prepared before parallel work.
- Frame workers: Auto selects a bounded number based on CPUs and frame size.
Manual 1–8 is still capped for CPU/frame memory. Frames are written in order.
- Encoder Auto probes NVIDIA NVENC, Intel Quick Sync and AMD AMF and performs a
real tiny encode to verify availability. It uses CPU H.264 if unavailable.
- Requested hardware encoding also falls back to CPU when unavailable or when
encoding fails. GPU encoding accelerates compression; image rendering is on CPU.
- Video writes to a temporary file and replaces the destination only on success.

The project JSON records the encoder and worker count actually used for export.
GPU pixel rendering, Gaia distances and foreground-only brightness boost are not
implemented in this release.

## Data and projects

Use stretched images. High-precision TIFF and FITS handling is preserved from the
hotfix; there is no automatic astro-stretch. FITS is vertically flipped to match
image-editor orientation. Float data is preferably normalized to 0–1.
The selected output ratio center-crops the input without stretching the artwork.

**Save project… / Open project…** stores/restores the original source paths,
camera keyframes, all new star/render settings, seed, nebula depth and protection
mask. Keep JSON and `.depth.npz` together. Images are referenced, not embedded.
After moving originals, update their paths in the JSON. Old schemas load with new
safe defaults: original stars only, 35% nebula motion and 100% intensity.

**Export Both Depth Maps** now also writes `nebula_protection_16bit.png`.
Optional AI nebula refinement remains available through `requirements-ai.txt`.
It is not required for V1.3.1 stars and was not exercised in this validation.

## Limits and validation

Depths are artistic, not measured astronomical distances. Detection can merge
blended sources or reject isolated pixels/broad artifacts. Very faint disconnected
halo/spike pixels outside a sprite's soft support may be omitted. Large camera
magnification resamples existing sprites. Strong camera angles can distort the
2.5D nebula; borders use reflection. Automatic protection prioritizes broad bright
and colored structure; inspect the mask for dark or extremely faint targets.
No hidden stars are inferred behind opaque nebulae. Synthetic additions are an
explicit artistic option and can be turned off completely.

Run `python -m unittest discover -s tests -v`. See `VALIDATION.md` for measured
comparison and remaining platform limits. Screenshots alone were supplied, not a
full user starless/mask pair, so exact user-image validation still needs those files.
